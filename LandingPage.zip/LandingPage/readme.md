# HTML5 - CSS Lesson
Welcome to my first Landing Page.

<details open="">
  <summary><h2>✨About this</h2></summary>
  <br>
<p dir="auto"> 
    In internet marketing, Landing page is a web page to which a person
    arrives after clicking on the link or button in a guide, a portal or some banner or advertisement
    text located on another web page, application, social network, email or internet portal
</p>
</details>


<details open="">
  <summary><h2>✨Why is it so important?</h2></summary>
<p dir="auto">
  </br>
  His reasoning is simple: if we offer something that seduces the user, 
  he will be more willing to leave information through a form, 
  if with this he will be able to access it and other content of interest.
</p>
</details>


<details open="">
  <summary><h2>✨Give some feedbacks</h2></summary>
<p dir="auto">
  This repository is one of some season of courses I am doing, feel as your home reading it, we will learn together, it is ok if you have any question, and do not forget giving me some feedback.
  </br>
  <ul>
    <li><a href="https://edwincruz13.github.io/LandingWeb/">Landing Page</a></li>
    <li><a href="https://github.com/EdwinCruz13/MERN">MERN</a></li>
    <li><a href="#">Mongo</a></li>
    <li><a href="#">Express</a></li>
    <li><a href="#">React</a></li>
    <li><a href="https://github.com/EdwinCruz13/NodeJS-Lesson">NodeJS</a></li>
  </ul>

</p>
</details>